export const apiUrl = process.env.NODE_ENV === 'production' ? 'http://120.78.14.107/api/' : '/api/'
export const qiniu = 'http://api.qiniu.com/qiniu/'
export const upload = 'http://upload.qiniup.com/upload/'
export const imgUrl = 'https://dn-simplecloud.shiyanlou.com/'
