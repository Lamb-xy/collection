<template>
    <div class="publish_home_div">
        <Publish></Publish>
    </div>
</template>

<script type="text/javascript">

import Publish from '@/components/publish_page/publish.vue'

export default {
    components: {
        Publish
    },
}
</script>
<style type="text/css">
</style>
