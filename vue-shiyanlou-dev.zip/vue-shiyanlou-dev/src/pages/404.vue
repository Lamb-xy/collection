<template>
    <div class="not_found_div">
        <NotFound></NotFound>
    </div>
</template>
<script type="text/javascript">
    
import NotFound from '@/components/common_components/404.vue'


export default {
    components: {
        NotFound
    },

}
</script>
<style type="text/css">
</style>
