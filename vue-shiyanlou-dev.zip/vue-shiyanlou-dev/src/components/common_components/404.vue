<template>
    <div class="not_found_page_div">
        <img class="not_found_wrap_image" src="https://static.shiyanlou.com/frontend/dist/img/9692684.png">
        <div class="not_found_side">
            <img class="not_found_side_404" src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxNjUiIGhlaWdodD0iNzMiIHZpZXdCb3g9IjAgMCAxNjUgNzMiPgogICAgPGcgZmlsbD0ibm9uZSIgZmlsbC1ydWxlPSJldmVub2RkIj4KICAgICAgICA8cGF0aCBmaWxsPSIjRjZGNkY2IiBkPSJNLTgxNi0yMzFINjI0djg0MkgtODE2eiIvPgogICAgICAgIDxwYXRoIGZpbGw9IiM2NjYiIGQ9Ik0wIDUyLjAxNkwyMy45NTcuNTkxSDM1LjQyTDExLjE2NyA1Mi4wMTZIMjkuOTFWMzEuMzc3SDQwLjE5djIwLjY0aDUuNzA2djkuNzAzaC01LjcwNnYxMC42ODlIMjkuOTFWNjEuNzJIMHYtOS43MDR6TTkyLjU2IDIxLjI4Yy0uMTk3LTcuMTkxLTMuNTU4LTEwLjg1My0xMC4wODUtMTAuOTg0LTYuNTU5LjEzMS05LjkwNCAzLjc5My0xMC4wMzUgMTAuOTg0djMwLjQ0MmMuMTMxIDcuMjU3IDMuNDc2IDEwLjkxOCAxMC4wMzUgMTAuOTg0IDYuNTI3LS4wNjYgOS44ODgtMy43MjcgMTAuMDg1LTEwLjk4NFYyMS4yNzl6bS0zMC40MDEtLjY0Yy4wNjUtNi42MzMgMi4xOC0xMS43NCA2LjM0NS0xNS4zMkM3Mi40MDcgMS43NzQgNzcuMDY0IDAgODIuNDc1IDBjNS41NzYgMCAxMC4zMTUgMS43NzMgMTQuMjE3IDUuMzIgMy45NjkgMy41OCA2LjAxOCA4LjY4NiA2LjE1IDE1LjMxOXYzMS42NzNjLS4xMzIgNi42LTIuMTgxIDExLjY5LTYuMTUgMTUuMjctMy45MDIgMy41NDYtOC42NDEgNS4zNTItMTQuMjE3IDUuNDE4LTUuNDEtLjA2Ni0xMC4wNjgtMS44NzItMTMuOTctNS40MTgtNC4xNjYtMy41OC02LjI4LTguNjctNi4zNDYtMTUuMjdWMjAuNjM5em01Ni45NDQgMzEuMzc3TDE0My4wNi41OTFoMTEuNDYybC0yNC4yNTMgNTEuNDI1aDE4Ljc0M1YzMS4zNzdoMTAuMjgydjIwLjY0SDE2NXY5LjcwM2gtNS43MDZ2MTAuNjg5aC0xMC4yODJWNjEuNzJoLTI5Ljkxdi05LjcwNHoiLz4KICAgIDwvZz4KPC9zdmc+Cg==">
            <p class="text">
                Sorry，页面走丢了...
            </p>
            <a href="/" class="back_to_home_button">
                返回首页
            </a>
        </div>
    </div>
</template>
<script type="text/javascript">
    
</script>
<style type="text/css" scoped>
.not_found_page_div {
    width: 1170px;
    padding: 30px;
    padding-top: 150px;
    margin: auto;
    display: flex;
    justify-content: center;
    align-items: center;
}

.not_found_wrap_image {
    width: 300px;
    margin-right: 100px;
}

.not_found_side {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
}

.not_found_side_404 {
    width: 150px;
}

.text {
    padding: 30px 0;
    color: #666;
    font-size: 20px;
    margin: 0;
}

.back_to_home_button {
    color: #fff;
    border-color: #08bf91;
    background-color: #08bf91;
    border: 1px solid transparent;
    padding: .375rem .75rem;
    font-size: 1rem;
    line-height: 1.5;
    border-radius: .25rem;
    transition: color .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out;
}

.back_to_home_button:hover {
    color: #fff;
    border-color: #069a75;
    background-color: #069a75;;
}

</style>
