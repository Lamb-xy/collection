<template>
    <div class="path_div">
        <TitleBackground></TitleBackground>
        <Paths></Paths>
    </div>
</template>
<script type="text/javascript">
import TitleBackground from './sub_components/title.vue'
import Paths from './sub_components/paths.vue'

export default {
    components: {
        TitleBackground,
        Paths
    }
}

</script>
<style type="text/css" scoped>

</style>
