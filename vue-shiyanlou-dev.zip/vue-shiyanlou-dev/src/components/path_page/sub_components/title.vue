<template>
    <div class="title_background">
    </div>
</template>
<script type="text/javascript">

</script>
<style type="text/css" scoped>
.title_background {
    height: 340px;
    background: url(https://static.shiyanlou.com/img/path_bg.png) no-repeat;
    background-position: 50% 0;
    margin-top: -20px;
    margin-bottom: -30px;
}
</style>
